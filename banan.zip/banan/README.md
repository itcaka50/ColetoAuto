# ColetoAuto
Proekt Cvqtko Medkov Noshtnata Ptica na Bulgaria Koev, Lucho, Ico

TABLICI:
User(id, names, password, address, age, email, phone), Admin(redactira listings)
Cars(id, marka, model, hp, price, probeg, godina, desc) foreign key marka, foreign key model
Flight(id, marka, model, price, desc, trust) foreign key marka, foreign key model
Lodki(id, marka, model, price, hp, desc) foreign key marka, foreign key model
Chasti(cena, marka, model) foreign key marka, foreign key model
Marka
Model

WEBSITE:
LOG PAGE
MAIN PAGE
BUY PAGE
RESULTS PAGE
ADMIN PAGE